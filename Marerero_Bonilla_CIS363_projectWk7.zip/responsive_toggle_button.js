// JavaScript Document

function myFunction()
{
	var X = document.getElementById("myTopnav");
	if (X.className === "topnav")
		{
			X.className += "responsive";
		}
	else
		{
			X.className = "topnav";
		}
}